Rails.application.routes.draw do
  resources :widgets


  # Defines the root path route ("/")
  # root "articles#index"
# START:edit:3
  get "manufacturer/:id", to: "manufacturers#show"
# END:edit:3
end
