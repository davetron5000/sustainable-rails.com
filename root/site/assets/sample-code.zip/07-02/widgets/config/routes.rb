Rails.application.routes.draw do
# START:edit:3
  resources :widgets, only: [ :show ]
# END:edit:3

  get "manufacturer/:id", to: "manufacturers#show"
end
