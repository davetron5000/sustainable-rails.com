Rails.application.routes.draw do
# START:edit:3
  resources :widgets, only: [ :show ]
# END:edit:3


  # Defines the root path route ("/")
  # root "articles#index"
  get "manufacturer/:id", to: "manufacturers#show"
end
